---
name: Discussion
about: Any question about the Editor.js to discuss
title: ''
labels: discussion
assignees: ''

---

The question.

Why and how the question has come up.

<!--
🤫 If you like Editor.js, please consider supporting us via OpenCollective:
https://opencollective.com/editorjs
-->
