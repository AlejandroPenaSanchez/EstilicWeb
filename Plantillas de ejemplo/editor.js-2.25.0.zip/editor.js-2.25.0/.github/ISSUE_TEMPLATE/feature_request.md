---
name: Feature request
about: Suggest an idea to improve Editor.js
title: "\U0001F4A1"
labels: feature
assignees: ''

---

1. Describe a problem.

2. Describe the solution you'd like. Mockups are welcome.

3. Are there any alternatives?

<!--
🤫 If you like Editor.js, please consider supporting us via OpenCollective:
https://opencollective.com/editorjs
-->
